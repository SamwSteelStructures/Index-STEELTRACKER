// netlify/functions/kv.mjs
// Shared key-value store for SteelTrack, backed by Netlify Blobs.
// All visitors of the site read/write ONE dataset (site-scoped store).
// Routes: GET/POST/DELETE /api/kv  and  GET /api/kv/list
import { getStore } from "@netlify/blobs";

const STORE = "steeltrack";
const LOT_PREFIX = "steeltrack:lot:";
const INDEX_KEY = "steeltrack:lots-index";

// strong consistency = a save is immediately visible on the next read
function store() {
  return getStore({ name: STORE, consistency: "strong" });
}

export default async (req) => {
  const url = new URL(req.url);
  const s = store();

  // ---- GET /api/kv/list?prefix= ----
  if (url.pathname.endsWith("/list")) {
    const prefix = url.searchParams.get("prefix") || "";
    const { blobs } = await s.list({ prefix });
    return Response.json({ keys: blobs.map((b) => b.key) });
  }

  const key = url.searchParams.get("key") || "";

  if (req.method === "GET") {
    if (!key) return Response.json({ error: "missing key" }, { status: 400 });

    // Self-healing package index: return the union of the stored index and the
    // ids of package rows that actually exist, so two people creating packages
    // at the same time can never wipe each other out of the list.
    if (key === INDEX_KEY) {
      let stored = [];
      const raw = await s.get(INDEX_KEY, { type: "text" });
      if (raw) { try { stored = JSON.parse(raw) || []; } catch { /* ignore */ } }
      const { blobs } = await s.list({ prefix: LOT_PREFIX });
      const ids = blobs.map((b) => b.key.slice(LOT_PREFIX.length));
      const seen = new Set();
      const merged = [];
      for (const id of stored) if (!seen.has(id)) { seen.add(id); merged.push(id); }
      for (const id of ids) if (!seen.has(id)) { seen.add(id); merged.push(id); }
      return Response.json({ value: JSON.stringify(merged) });
    }

    const value = await s.get(key, { type: "text" });
    return Response.json({ value: value ?? null });
  }

  if (req.method === "POST") {
    const body = await req.json().catch(() => ({}));
    const k = body && body.key;
    const v = body && body.value;
    if (!k || typeof v !== "string") return Response.json({ error: "bad request" }, { status: 400 });
    await s.set(k, v);
    return Response.json({ ok: true });
  }

  if (req.method === "DELETE") {
    if (!key) return Response.json({ error: "missing key" }, { status: 400 });
    await s.delete(key);
    return Response.json({ ok: true });
  }

  return Response.json({ error: "method not allowed" }, { status: 405 });
};

export const config = { path: ["/api/kv", "/api/kv/list"] };
